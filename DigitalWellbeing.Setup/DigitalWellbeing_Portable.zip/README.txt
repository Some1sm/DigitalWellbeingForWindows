DigitalWellbeing Portable
=========================

Usage:
1. Run 'DigitalWellbeingWPF.exe' to start the application.
2. The background service 'DigitalWellbeingService.NET4.6.exe' should start automatically or be managed by the app.

Requirements:
- .NET Framework 4.7.2
